# cloudlets vs clouds.

## ![Alt text](image.png)