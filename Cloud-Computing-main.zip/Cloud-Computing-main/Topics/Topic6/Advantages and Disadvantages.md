# Advantages and Disadvantages:

## Advantages :
-   Saves battery power
-   Makes execution faster
-   Improves data storage capacity and processing power
-   Improves reliability and availability : Keeping data and application in the clouds
reduces the chance of lost on the mobile devices

-   Dynamic provisioning : Dynamic on-demand provisioning Of resources on a
fine-grained, self-service basis.


## Disadvantages :

1. Must the program states (data) to the cloud server.

2. Network latency can lead to execution delay.