# Characteristics of CC:


-    On-demand self-service: Users can provision computing resources, such as processing power and storage, without having to go through a human intermediary.


-    Broad network access: Cloud services are accessible over the internet from a variety of devices, including laptops, smartphones, and tablets.

-   Resource pooling: Cloud providers use multi-tenant architectures to share computing resources among multiple users, which allows for greater efficiency and cost savings.

-   Rapid elasticity: Cloud resources can be quickly and easily scaled up or down to meet changing demands, without requiring significant changes to the underlying infrastructure.

-    Measured service: Cloud providers track resource usage and charge users based on the resources they consume, which allows for more accurate and cost-effective billing.On-demand self-service: Users can provision computing resources, such as processing power and storage, without having to go through a human intermediary.

