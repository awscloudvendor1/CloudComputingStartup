# Microsoft Cloud Services : Azure

-   Windows Azure is a cloud computing platform and infrastructure, created by Microsoft, for building, deploying and managing applications and services through global network of Microsoft - managed data centers.

-  Azure is a virtualized infrastructure to which a set of additional enterprise services has been layered on top, including, a virtualization service called Azure.

-   AppFabric is a cloud-enabled version Of the .NET framework.

-  Windows Azure is Microsoft's application platform for the public Cloud.

## Windows Azure is used to :
1) Build a web application that runs and stores its data in Microsoft data centers.

2) Store data while the applications that consume this data run on premise.

3) Create virtual machines to develop and test, or run SharePoint and Other out-of-the-box applications.

4) evelop massively scalable applications with many users.

5) Offer a wide range Of services.

## Advantages of Microsoft Azure:

1. Microsoft Azure offers high availability
2. It offers you a strong security profile
3. It is a cost-effective solution for an IT budget.
4. Azure allows you to use any framework, language, or tool.
5. Azure allows businesses to build a hybrid infrastructure.