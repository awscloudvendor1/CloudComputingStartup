# Advantages:

-   Easy to use.
-  No capacity limits : Organizations launch different projects and the guess what capacity they will need.
-  Provides speed and agility.
-  Secure and reliable : AWS provides security and also helps to protect the privacy as it is stored in AWS data centers.


# Disadvantages:

-  Limitations Of Amazon EC2 : AWS sets default limits on resources which vary from region to region. These resources consist Of images, volumes, and snapshots.
-  Technical support fee : AWS charges you for immediate support.
-  Security Limitations.