# NAS (Network attached Storage)-

-   Network-Attached Storage (NAS) is a type of storage solution that connects to a computer network, allowing multiple devices to access and share files and data. 

-   NAS devices are dedicated file servers that provide storage capacity and file sharing services to the network users.

-   In simple terms, NAS is like a storage box connected to your home network. It acts as a central hub where all devices on the network can store and retrieve files.

## Advantages:

1) Easy File Sharing
2) Centralized Storage Management.
3) Data Redundancy and Protection.
4) Data Backup
5) Remote Access
6) Scalability
7) Cost-Effective Storage