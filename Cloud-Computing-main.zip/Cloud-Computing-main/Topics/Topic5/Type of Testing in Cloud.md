# Type of Testing in Cloud:

• The whole cloud testing is divided into four main types,

a) Testing Of the whole cloud: The cloud is viewed as a whole entity and based on its features testing is carried out. Cloud and SaaS vendors, as well as end
users, are interested in carrying out this type of testing.

b) Testing within a cloud : By checking each of its internal features, testing is carried out. Only cloud vendors can perform this type of testing.

c) Testing across cloud : Testing is carried out on different types of cloud-like private, public and hybrid clouds.

d) SaaS testing in cloud : Functional and non-functional testing is carried out on
the basis Of application requirements.